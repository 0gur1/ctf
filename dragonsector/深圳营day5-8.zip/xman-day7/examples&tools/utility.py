import socket
import logging as log
import threading
import sys
import select
import struct
import os

log.basicConfig(format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p', level=log.INFO)


class pwn:
    data = ''

    def __init__(self, address):
        if type(address) is str:
            address = str(address)
            if address.count(':') == 1:
                tmp = address.split(':')
                ip = tmp[0]
                port = int(tmp[1])
            else:
                raise ValueError('Address illegal')
        elif type(address) is list or type(address) is tuple:
            if len(address) > 1:
                ip = address[0]
                port = int(address[1])
            else:
                raise ValueError('Address illegal')
        else:
            raise ValueError('Address illegal')
        ip = socket.gethostbyname(ip)
        self.s = socket.socket()
        self.s.connect((ip, port))
        log.info('Connect {}:{} success!'.format(ip, port))

    def recv(self, n=4096, timeout=0.1):
        if n > len(self.data):
            size = 4096
            if n > size:
                tmp = n / size
                size *= (tmp + 1)
            data = ''
            first = True
            while 1:
                read_sockets, write_sockets, error_sockets = select.select([self.s], [], [], timeout)

                if len(read_sockets):
                    for sock in read_sockets:
                        try:
                            tmp = sock.recv(size - len(data))
                            data += tmp

                            if not tmp:
                                log.warning('Disconnected in recv')
                                self.data += data
                                data = self.data[:n]
                                self.data = self.data[n:]
                                return data
                            first = False
                        except Exception as e:
                            log.warning('Disconnected in recv exception')
                            log.debug(e.message)
                            self.data += data
                            data = self.data[:n]
                            self.data = self.data[n:]
                            return data
                    if len(data) >= size:
                        break
                else:
                    if first:
                        continue
                    else:
                        break

            self.data = self.data + data
            data = self.data[:n]
            self.data = self.data[n:]
        else:
            data = self.data[:n]
            self.data = self.data[n:]
        return data

    def send(self, buf):
        socket_list = [self.s]

        read_sockets, write_sockets, error_sockets = select.select([], socket_list, [], 0.1)
        for sock in write_sockets:
            sock.send(buf)
            return True
        return None

    def sendline(self, buf):
        self.send(buf + '\n')

    def sendafter(self, delim, buf):
        self.recvuntil(delim)
        self.send(buf)

    def sendlineafter(self, delim, buf):
        self.recvuntil(delim)
        self.sendline(buf)

    def recvuntil(self, delim, drop=False):
        data = ''
        while delim not in data:
            tmp = self.recv(1)
            if not tmp:
                break
            data += tmp

        try:
            p = data.index(delim)
            self.data = self.data + data[p + len(delim):]

            if drop:
                data = data[:p]
            else:
                data = data[:p + len(delim)]

            return data
        except:
            return data

    def close(self):
        log.warning('Closing connection')
        self.shutdown()
        self.s.close()

    def shutdown(self, how='both'):
        if how == 'both':
            self.s.shutdown(socket.SHUT_WR)
        elif how == 'read':
            self.s.shutdown(socket.SHUT_RD)
        elif how == 'write':
            self.s.shutdown(socket.SHUT_WR)

    def interactive(self):
        log.info('Entering interactive mode')

        sys.stdout.write(self.data)
        self.data = None

        class PrintThread(threading.Thread):
            def __init__(self, sock):
                threading.Thread.__init__(self)
                self.s = sock

            def run(self):
                try:
                    while 1:
                        socket_list = [self.s]
                        # Get the list sockets which are readable
                        read_sockets, write_sockets, error_sockets = select.select(socket_list, [], [])
                        for sock in read_sockets:
                            data = sock.recv(4096)
                            if not data:
                                log.warning('Disconnected')
                                realexit()
                            else:
                                # print data
                                sys.stdout.write(data)
                except Exception as e:
                    log.warning('Disconnected from remote')
                    log.debug(e.message)
                    realexit()

        pt = PrintThread(self.s)
        pt.start()

        try:
            while 1:
                data = sys.stdin.readline()
                if not data:
                    return
                if self.send(data):
                    continue
                else:
                    return
        except:
            return


def realexit():
    os._exit(0)


def p8(data):
    return struct.pack('<B', data)


def p16(data):
    return struct.pack('<H', data)


def p32(data):
    return struct.pack('<I', data)


def p64(data):
    return struct.pack('<Q', data)


def u8(data):
    return struct.unpack('<B', data)[0]


def u16(data):
    return struct.unpack('<H', data)[0]


def u32(data):
    return struct.unpack('<I', data)[0]


def u64(data):
    return struct.unpack('<Q', data)[0]
