final = [100, 50, 74, 205, 52, 230, 93, 130, 182, 83, 11, 57, 200, 231, 33, 113]
keys = [86, 252, 216, 102]
ori = [65, 255, 243, 219, 6, 179, 105, 194, 144, 163, 33, 143, 123, 109, 50, 140]
after = []
flag = []
for i in range(16):
	a = keys[i%4]^((ori[i] >> i % 4) | (ori[i] << int(i / 4)))
	after.append(a)
print(after)

for i in range(16):
	flag.append(chr((after[i]^final[i])&0xff))
print(''.join(flag))
